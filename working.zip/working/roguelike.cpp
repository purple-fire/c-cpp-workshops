#include "roguelike.hpp"

/**
 * All constructors/destructors as well as simple accessors/mutators
 * are inlined in the roguelike.hpp file.
 */

/**
 --------------------------
 --  BASE CLASS METHODS  --
 --------------------------
 */

/**
 * Performs an attack on the target, reducing its health.
 */
void BattleEntity::attack(BattleEntity target) {
    // TODO
}

/**
 * Prints an acquisition message for the item.
 */
void AbstractItem::printFind() const {
    // TODO
}


/**
 ----------------------------------
 --  DERIVED ITEM CLASS METHODS  --
 ----------------------------------
 */

/**
 * Uses the item on the given target.
 */
void HealingItem::use(BattleEntity target) const {
    // TODO
}

/**
 * Uses the item on the given target.
 */
void EquippableItem::use(BattleEntity target) const {
    // TODO
}


/**
 ------------------------------------
 --  DERIVED BATTLE CLASS METHODS  --
 ------------------------------------
 */

/**
 * Attempts to add the given item to inventory.
 * Will do nothing and return false if inventory is full.
 */
bool Hero::addItem(AbstractItem item) {
    // TODO
}

/**
 * Attempts to use and consume the given item.
 * Will do nothing if passed an invalid index.
 */
void Hero::useItem(unsigned int slot) {
    // TODO
}

/**
 * Performs a special attack on the target, reducing its health by more 
 * than usual and displaying a unique message.
 */
void Enemy::specialAttack(BattleEntity target) {
    // TODO
}
