#ifndef ROGUELIKE_HPP
#define ROGUELIKE_HPP

#include <string>
#include <vector>


/**
 --------------------
 --  BASE CLASSES  --
 --------------------
 */

class BattleEntity {
private:
    unsigned int maxHealth;
    unsigned int currentHealth;
    int attackPower;
    int defensePower;

public:
    // Constructor
    BattleEntity(unsigned int hp, int atk, int def) : 
        maxHealth(hp), currentHealth(hp), attackPower(atk), defensePower(def) {};

    // Accessors and mutators
    unsigned int getMaxHealth() const { return maxHealth; }
    void setMaxHealth(unsigned int value) { maxHealth = value; }
    unsigned int getCurrentHealth() const { return currentHealth; }
    void setCurrentHealth(unsigned int value) { currentHealth = value; }
    int getAttackPower() const { return attackPower; }
    void setAttackPower(int value) { attackPower = value; }
    int getDefensePower() const { return defensePower; }
    void setDefensePower(int value) { defensePower = value; }

    /**
     * Performs an attack on the target, reducing its health.
     */
    void attack(BattleEntity target);
};

class AbstractItem {
private:
    std::string name;
    std::string flavor;

public:
    // Constructor
    AbstractItem(std::string name, std::string flavor) :
        name(name), flavor(flavor) {};

    // Accessors and mutators
    std::string getName() const { return name; }
    std::string getFlavor() const { return flavor; }

    /**
     * Uses the item on the given target.
     */
    virtual void use(BattleEntity target) const;

    /**
     * Prints an acquisition message for the item.
     */
    void printFind() const;
};


/**
 ----------------------------
 --  DERIVED ITEM CLASSES  --
 ----------------------------
 */

class HealingItem: public AbstractItem {
private:
    int healAmount;
public:
    // Constructor
    HealingItem(std::string name, std::string flavor, int health) :
        healAmount(health), AbstractItem(name, flavor) {};
    // Virtual function definitions
    virtual void use(BattleEntity target) const;
};

class EquippableItem: public AbstractItem {
private:
    int healthBuff;
    int attackBuff;
    int defenseBuff;
public:
    // Constructor
    EquippableItem(std::string name, std::string flavor, int health, int attack, int defense) :
        healthBuff(health), attackBuff(attack), defenseBuff(defense), AbstractItem(name, flavor) {};
    // Virtual function definitions
    virtual void use(BattleEntity target) const;
    // Accessors and mutators
    int getHealthBuff() const { return healthBuff; }
    int getAttackBuff() const { return attackBuff; }
    int getDefenseBuff() const { return defenseBuff; }
};

class Armor: public EquippableItem {
public:
    // Constructor
    Armor(std::string name, std::string flavor, int health, int attack, int defense) :
        EquippableItem(name, flavor, health, attack, defense) {};
};

class Weapon: public EquippableItem {
public:
    // Constructor
    Weapon(std::string name, std::string flavor, int health, int attack, int defense) :
        EquippableItem(name, flavor, health, attack, defense) {};
};


/**
 ------------------------------
 --  DERIVED BATTLE CLASSES  --
 ------------------------------
 */

class Hero: public BattleEntity {
private:
    // Hero is a special class, so give it certain special default values.
    Armor armor = Armor("Leather Coat", "A plain coat for keeping warm. Not very defensive.", 0, 0, 0);
    Weapon weapon = Weapon("Bare Hands", "The weapons you were born with. Works in a pinch.", 0, 0, 0);
    std::vector<AbstractItem> inventory;
    unsigned int inventory_size;

public:
    // Constructor
    // For simplicity, defaults everything to empty
    Hero(unsigned int hp, int atk, int def, unsigned int inv) : 
        inventory(std::vector<AbstractItem>()), inventory_size(inv),
        BattleEntity(hp, atk, def) {};

    // Accessors and mutators
    Armor getArmor() const { return armor; }
    void setArmor(Armor armor) { this->armor = armor; }
    Weapon getWeapon() const { return weapon; }
    void setWeapon(Weapon weapon) { this->weapon = weapon; }
    std::vector<AbstractItem> getInventory() const { return inventory; }

    /**
     * Attempts to add the given item to inventory.
     * Will do nothing and return false if inventory is full.
     */
    bool addItem(AbstractItem item);

    /**
     * Attempts to use and consume the given item.
     * Will do nothing if passed an invalid index.
     */
    void useItem(unsigned int slot);
};

class Enemy: public BattleEntity {
private:
    std::string name;
    std::string specialText;

public:
    // Constructor
    Enemy(std::string name, std::string specialText, unsigned int hp, int atk, int def) : 
        name(name), specialText(specialText),
        BattleEntity(hp, atk, def) {};

    // Accessors and mutators
    std::string getName() const { return name; }

    /**
     * Performs a special attack on the target, reducing its health by more 
     * than usual and displaying a unique message.
     */
    void specialAttack(BattleEntity target);
};


#endif // ROGUELIKE_HPP