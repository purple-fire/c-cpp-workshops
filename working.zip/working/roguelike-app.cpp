#include <iostream>
#include <string>
#include <vector>
#include "roguelike.hpp"

// Print welcome message
// Choose initial item/armor
// Start gameplay loop
//   Choose random enemy to battle
//   Start battle loop
//     Player turn (Attack/Item)
//     Check battle status
//     Enemy turn (Attack/Special)
//     Check battle status
//     Exit battle loop if needed
//   Exit gameplay loop if needed
//   Start chest room sequence
//     Choose random items in each chest
//     Choose a chest to open
//     Receive item
// Final stats
// Exit

// Function prototypes
unsigned int get_choice(std::string, unsigned int);
void run_intro_sequence();
void show_final_stats();

// Static/constant data
static const std::string STARTUP_MESSAGE = "\
~~~~~~~~~~~~~~~~~~~~~~~~\n\
~~~ Dungeon Defender ~~~\n\
~~~~~~~~~~~~~~~~~~~~~~~~\n";

static const std::vector<Armor> ALL_ARMORS = {
    Armor("Chain Chestplate", "A chainmail chestpiece once used by soldiers. Increases defense by 2.", 0, 0, 2),
};
static const std::vector<Weapon> ALL_WEAPONS = {
    Weapon("Rusted Shortsword", "A rusty sword once used by soldiers. Increases attack by 2.", 0, 2, 0),
};
static const std::vector<HealingItem> ALL_HEALING_ITEMS = {
    HealingItem("Crimson Elixir", "A red-colored potion commonly used to treat wounds. Restores 5 health.", 5),
};
static const std::vector<Enemy> ALL_ENEMIES = {
    Enemy("Slime", "rolls around wildly!", 10, 2, 1),
};

static Hero player = Hero(20, 5, 5, 10);
static Enemy current_enemy = Enemy("NULL", "NULL", 0, 0, 0);
static unsigned int current_room = 1;


int main()
{
    /**
     * Introduction sequence
     */
    std::cout << STARTUP_MESSAGE << std::endl;
    run_intro_sequence();

    /**
     * Start main gameplay loop
     */
    while (true)
    {
        // TODO
        break;
    }

    /**
     * Print the final stats of the run and exit
     */
    show_final_stats();
    return 0;
}

unsigned int get_choice(std::string prompt, unsigned int max) {
    std::cout << prompt << std::endl;
    unsigned int choice = 0;
    while (!choice || choice > max) {
        std::cout << " > ";
        std::cin >> choice;
    }
    return choice;
}

void run_intro_sequence() {
    std::cout <<
    "You come across a strange ruin deep in an unexplored jungle.\n" <<
    "In front of you lie three stone archways, each containing an item:\n" <<
    " 1. In the first door, you see a WEAPON.\n" <<
    " 2. In the second door, you see a piece of ARMOR." << std::endl;
    switch (get_choice("Which door do you enter?", 2)) {
        case 1:
            ALL_WEAPONS[0].printFind();
            player.setWeapon(ALL_WEAPONS[0]);
            break;
        case 2:
            ALL_ARMORS[0].printFind();
            player.setArmor(ALL_ARMORS[0]);
            break;
    }
    std::cout <<
    "As you pick up the item, the ceiling of the doorway you entered through\n" <<
    "suddenly rumbles and collapses, trapping you inside.\n" <<
    "Equipping the item you picked up, you turn toward the tunnel that lies\n" <<
    "before you and begin to search for an exit." << std::endl;
}

void show_final_stats() {
    // TODO
}